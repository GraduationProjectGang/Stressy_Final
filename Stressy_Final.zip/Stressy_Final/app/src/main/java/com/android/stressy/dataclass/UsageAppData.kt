package com.android.stressy.dataclass


data class UsageAppData(val packageName:String, val lastTimeUsed: String, val totalTimeInForeground:Long)