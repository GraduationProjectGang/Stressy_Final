package com.android.stressy.activity.sign_up

import android.app.Fragment
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.core.os.bundleOf
import androidx.navigation.findNavController
import com.android.stressy.R
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.fragment_sign_up1.*
import java.util.regex.Pattern


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class SignUp1Fragment : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootView = inflater.inflate(R.layout.fragment_sign_up1, container, false)
        return rootView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        init(view)
    }

    fun init(rootView:View){
        val nextButton1 = rootView.findViewById<Button>(R.id.nextButton1)
        nextButton1.setOnClickListener {
            //if email is valid
            val emailInput = editText_email.text.toString()
            val passwordInput = editText_password.text.toString()
            if ("@" in emailInput && "." in emailInput){
                if(!requestEmailCheck()) {
                    Snackbar.make(it, "이미 가입되어 있는 이메일입니다.", Snackbar.LENGTH_SHORT).show()
                }else if (!isValidPassword(passwordInput) or (passwordInput.length <= 8)){
                    guide_password.visibility = TextView.VISIBLE
                }else{
                    toSignUp2(emailInput,passwordInput)
                }
            }else{
                guide_email.visibility = TextView.VISIBLE
            }
        }
    }
    fun toSignUp2(userEmail:String, userPassword:String){
        var bundle = bundleOf("userEmail" to userEmail, "userPassword" to userPassword)
        view?.findNavController()?.navigate(R.id.action_signUp1Fragment_to_signUp2Fragment, bundle)
    }
    val url = "114.70.23.77/user/account/validemail"
    fun requestEmailCheck():Boolean{
        return true
    }

    fun isValidPassword(input:String):Boolean{
        val PASSWORD_PATTERN =
            "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$"
        val pattern = Pattern.compile(PASSWORD_PATTERN)
        val matcher = pattern.matcher(input)

        return matcher.matches()
    }

}