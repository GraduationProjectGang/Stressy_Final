package com.android.stressy.dataclass

data class CategoryForJson(val appName:String, val packageName:String, val category:String) {
}
