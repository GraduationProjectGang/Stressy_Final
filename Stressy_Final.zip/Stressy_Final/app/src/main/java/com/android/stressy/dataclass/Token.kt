package com.android.stressy.dataclass

data class Token(
    var idx:Int,
    var token:String
) {}