package com.android.stressy.activity.sign_up

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.DatePicker
import androidx.fragment.app.Fragment
import com.android.stressy.R
import java.text.SimpleDateFormat
import java.util.*

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [SignUp4Fragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class SignUp4Fragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootView = inflater.inflate(R.layout.fragment_sign_up4, container, false)
        init(rootView)
        return rootView
    }

    private fun init(rootView:View) {
        val nextButton4 = rootView.findViewById<Button>(R.id.nextButton4)
        val button_birthday = rootView.findViewById<Button>(R.id.button_birthday)
        nextButton4.setOnClickListener {
            
        }
        button_birthday.setOnClickListener {
            var c = Calendar.getInstance()
            var datePickerDialog = DatePickerDialog(activity!!.applicationContext,
                MyDatePickerDialogListener(), c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
            datePickerDialog.window!!.setBackgroundDrawableResource(android.R.color.transparent)
            datePickerDialog.show();
        }


    }
    inner class MyDatePickerDialogListener:DatePickerDialog.OnDateSetListener{
        override fun onDateSet(p0: DatePicker?, year: Int, monthOfYear: Int, dayOfMonth: Int) {
            try {
                val d = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(year.toString()+"-"+(monthOfYear+1)+"-"+dayOfMonth)
            } catch ( e:Exception) {
                e.printStackTrace()
            }
        }
    }
}